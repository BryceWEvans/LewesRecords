<?php
session_destroy();
?>
<!DOCTYPE HTML>
<HTML>
<head>
<link rel="stylesheet" type="text/css" href="theme.css">
</head>
<body>
<h1> you've been signed out! </h1>
<a href="home.php"> <p> return home </p> </a>
</body>
</html>